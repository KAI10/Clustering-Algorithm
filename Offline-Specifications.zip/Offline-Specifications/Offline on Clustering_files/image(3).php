<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd" [
	<!ENTITY ns_flows "http://ns.adobe.com/Flows/1.0/">
]>
<svg version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
	 x="0px" y="0px" width="12px" height="12px" viewBox="0 0 12 12" style="overflow:visible;enable-background:new 0 0 12 12;"
	 xml:space="preserve" preserveAspectRatio="xMinYMid meet">
<defs>
</defs>
<path style="fill:#999999;" d="M11,0H1C0.5,0,0,0.5,0,1v10c0,0.5,0.5,1,1,1h10c0.5,0,1-0.5,1-1V1C12,0.5,11.5,0,11,0z M11,10
	c0,0.5-0.5,1-1,1H2c-0.5,0-1-0.5-1-1V4c0-0.5,0.5-1,1-1h8c0.5,0,1,0.5,1,1V10z M9,6.5v1C9,7.8,8.8,8,8.5,8H7v1.5
	C7,9.8,6.8,10,6.5,10h-1C5.2,10,5,9.8,5,9.5V8H3.5C3.2,8,3,7.8,3,7.5v-1C3,6.2,3.2,6,3.5,6H5V4.5C5,4.2,5.2,4,5.5,4h1
	C6.8,4,7,4.2,7,4.5V6h1.5C8.8,6,9,6.2,9,6.5z"/>
</svg>
