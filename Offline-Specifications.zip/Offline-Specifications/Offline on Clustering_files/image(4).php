<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd" [
	<!ENTITY ns_flows "http://ns.adobe.com/Flows/1.0/">
]>
<svg version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
	 x="0px" y="0px" width="12px" height="12px" viewBox="0 0 12 12" style="overflow:visible;enable-background:new 0 0 12 12;"
	 xml:space="preserve" preserveAspectRatio="xMinYMid meet">
<defs>
</defs>
<path style="fill:#999999;" d="M11,0H1C0.5,0,0,0.5,0,1v10c0,0.5,0.5,1,1,1h10c0.5,0,1-0.5,1-1V1C12,0.5,11.5,0,11,0z M11,10
	c0,0.5-0.5,1-1,1H2c-0.5,0-1-0.5-1-1V4c0-0.5,0.5-1,1-1h8c0.5,0,1,0.5,1,1V10z M4,6.6l0.7-0.7c0,0,0,0,0,0l1.8-1.8
	c0.2-0.2,0.5-0.2,0.7,0l0.7,0.7c0.2,0.2,0.2,0.5,0,0.7L6.4,7l1.5,1.5c0.2,0.2,0.2,0.5,0,0.7L7.2,9.9c-0.2,0.2-0.5,0.2-0.7,0L4,7.3
	C3.8,7.1,3.8,6.8,4,6.6z"/>
</svg>
