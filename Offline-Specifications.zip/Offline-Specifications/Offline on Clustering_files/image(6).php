<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd" [
	<!ENTITY ns_flows "http://ns.adobe.com/Flows/1.0/">
]>
<svg version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
	 x="0px" y="0px" width="24px" height="24px" viewBox="0 0 24 24" style="overflow:visible;enable-background:new 0 0 24 24;"
	 xml:space="preserve" preserveAspectRatio="xMinYMid meet">
<defs>
</defs>
<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="10.4995" y1="0" x2="10.4995" y2="19.4312">
	<stop  offset="0" style="stop-color:#76A1F0"/>
	<stop  offset="1" style="stop-color:#6B90D5"/>
	<a:midPointStop  offset="0" style="stop-color:#76A1F0"/>
	<a:midPointStop  offset="0.5" style="stop-color:#76A1F0"/>
	<a:midPointStop  offset="1" style="stop-color:#6B90D5"/>
</linearGradient>
<path style="fill:url(#SVGID_1_);" d="M19,0H2C0.9,0,0,0.9,0,2v11.3C0,14.4,0.9,15,2,15h0v4.4L6.1,15H19c1.1,0,2-0.5,2-1.6V2
	C21,0.9,20,0,19,0z"/>
<linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="10.4995" y1="0.9531" x2="10.4995" y2="16.8384">
	<stop  offset="0" style="stop-color:#BBE0F7"/>
	<stop  offset="1" style="stop-color:#82B4FB"/>
	<a:midPointStop  offset="0" style="stop-color:#BBE0F7"/>
	<a:midPointStop  offset="0.5" style="stop-color:#BBE0F7"/>
	<a:midPointStop  offset="1" style="stop-color:#82B4FB"/>
</linearGradient>
<path style="fill:url(#SVGID_2_);" d="M3,14H2c-0.4,0-1-0.1-1-0.6V2c0-0.6,0.5-1,1-1H19c0.5,0,1,0.5,1,1v11.3c0,0.6-0.8,0.6-1,0.6
	H5.7L3,16.8V14z"/>
<linearGradient id="SVGID_3_" gradientUnits="userSpaceOnUse" x1="10.4985" y1="1.9775" x2="10.4985" y2="14.314">
	<stop  offset="0" style="stop-color:#95BFF8"/>
	<stop  offset="0.5569" style="stop-color:#84ADEF"/>
	<stop  offset="1" style="stop-color:#7CA4EB"/>
	<a:midPointStop  offset="0" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="0.4" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="1" style="stop-color:#7CA4EB"/>
</linearGradient>
<path style="fill:url(#SVGID_3_);" d="M4,13c0,0-2,0-2,0V2l17,0l0,11c0,0-13.8,0-13.8,0L4,14.3V13z"/>
<path style="fill:#FFFFFF;" d="M17,11H4v-1h13V11z M17,8H4v1h13V8z M17,6H4v1h13V6z M17,4H4v1h13V4z"/>
<linearGradient id="SVGID_4_" gradientUnits="userSpaceOnUse" x1="15" y1="7.8955" x2="15" y2="23.897">
	<stop  offset="0" style="stop-color:#90C50E"/>
	<stop  offset="1" style="stop-color:#70A034"/>
	<a:midPointStop  offset="0" style="stop-color:#90C50E"/>
	<a:midPointStop  offset="0.5" style="stop-color:#90C50E"/>
	<a:midPointStop  offset="1" style="stop-color:#70A034"/>
</linearGradient>
<path style="fill:url(#SVGID_4_);" d="M22,7.9H8c-1.1,0-2,0.7-2,1.8v9c0,1.1,0.9,2,2,2v3.2l3.1-3H22c1.1,0,2-1.1,2-2.2v-9
	C24,8.6,23.1,7.9,22,7.9z"/>
<linearGradient id="SVGID_5_" gradientUnits="userSpaceOnUse" x1="15" y1="8.8955" x2="15" y2="21.3911">
	<stop  offset="0" style="stop-color:#D9F991"/>
	<stop  offset="0.2388" style="stop-color:#D7F88D"/>
	<stop  offset="0.4501" style="stop-color:#D1F383"/>
	<stop  offset="0.6509" style="stop-color:#C6EC71"/>
	<stop  offset="0.844" style="stop-color:#B7E257"/>
	<stop  offset="1" style="stop-color:#A8D73D"/>
	<a:midPointStop  offset="0" style="stop-color:#D9F991"/>
	<a:midPointStop  offset="0.7317" style="stop-color:#D9F991"/>
	<a:midPointStop  offset="1" style="stop-color:#A8D73D"/>
</linearGradient>
<path style="fill:url(#SVGID_5_);" d="M9,19.9H8c-0.6,0-1-0.7-1-1.2v-9c0-0.6,0.4-0.8,1-0.8h14c0.6,0,1,0.2,1,0.8v9
	c0,0.6-0.4,1.2-1,1.2H10.6L9,21.4V19.9z"/>
<linearGradient id="SVGID_6_" gradientUnits="userSpaceOnUse" x1="15" y1="9.8955" x2="15" y2="18.896">
	<stop  offset="0" style="stop-color:#B3E810"/>
	<stop  offset="1" style="stop-color:#90C60D"/>
	<a:midPointStop  offset="0" style="stop-color:#B3E810"/>
	<a:midPointStop  offset="0.5" style="stop-color:#B3E810"/>
	<a:midPointStop  offset="1" style="stop-color:#90C60D"/>
</linearGradient>
<polygon style="fill:url(#SVGID_6_);" points="10,18.9 8,18.9 8,9.9 22,9.9 22,18.9 10.2,18.9 10,18.9 "/>
<path style="fill:#FFFFFF;" d="M20,16.9H10v-1h10V16.9z M20,13.9H10v1h10V13.9z M20,11.9H10v1h10V11.9z"/>
</svg>
