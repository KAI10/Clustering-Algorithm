<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd" [
	<!ENTITY ns_flows "http://ns.adobe.com/Flows/1.0/">
]>
<svg version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
	 x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" style="overflow:visible;enable-background:new 0 0 16 16;"
	 xml:space="preserve" preserveAspectRatio="xMinYMid meet">
<defs>
</defs>
<path style="fill:#999999;" d="M10.5,9.6c0.7-0.2,1.4-0.5,2-0.9c2.5-1.5,4-3.7,3.3-4.9c-0.4-0.8-1.6-1-2.9-0.7
	c0.1-0.7,0.2-1.4,0.2-2c0-0.4,0-0.7,0-1c0,0-1.6,0.8-5,0.7C4.7,0.7,3,0,3,0c0,0.3,0,0.7,0,1c0,0.7,0.1,1.4,0.2,2.1
	c-1.4-0.3-2.6,0-3,0.7C-0.5,5.1,1,7.3,3.5,8.7c0.6,0.4,1.3,0.7,1.9,0.9c0.6,1.1,1.1,2.1,1.5,2.8C7,12.5,7,12.8,6.8,13H5l-2,3H13
	l-2-3H9.1c-0.2-0.2-0.2-0.5-0.1-0.6C9.3,11.7,9.8,10.8,10.5,9.6z M14.5,4.6c0.2,0.6-0.8,1.7-2.7,2.8c-0.1,0.1-0.2,0.1-0.3,0.2
	c0.4-0.9,0.8-1.9,1.1-2.9C13.5,4.3,14.3,4.2,14.5,4.6z M4.2,7.4c-2-1.1-3-2.2-2.7-2.8c0.2-0.4,1-0.3,2,0.1c0.3,1,0.6,2,1,2.9
	C4.4,7.5,4.3,7.5,4.2,7.4z"/>
</svg>
